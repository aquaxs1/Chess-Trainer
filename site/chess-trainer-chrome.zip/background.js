// Service Worker: sorgt nur dafür, dass das Offscreen-Dokument (hier läuft Stockfish) existiert.

let creating = null;

async function ensureOffscreen() {
  const existing = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
  if (existing.length > 0) return;
  if (!creating) {
    creating = chrome.offscreen
      .createDocument({
        url: "offscreen.html",
        reasons: ["WORKERS"],
        justification: "Stockfish-Engine in einem Web Worker ausfuehren",
      })
      .finally(() => {
        creating = null;
      });
  }
  await creating;
}

chrome.runtime.onInstalled.addListener(() => ensureOffscreen());
chrome.runtime.onStartup.addListener(() => ensureOffscreen());

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === "ensure-offscreen") {
    ensureOffscreen().then(
      () => sendResponse({ ok: true }),
      (err) => sendResponse({ ok: false, error: String(err) })
    );
    return true; // async response
  }
  return false; // alles andere gehört dem Offscreen-Dokument
});
