// Chess Trainer – content script for chess.com
// Ablauf (dauernd): Brett lesen -> FEN bauen -> Stockfish fragen -> Pfeil + Panel zeichnen.
// Läuft bewusst nur auf /play/computer (Spiele gegen Bots).

(() => {
  if (window.__schachTrainerLoaded) return;
  window.__schachTrainerLoaded = true;

  const CFG = {
    pollMs: 250, // wie oft das Brett geprüft wird
    onlyVsComputer: true,
  };

  // Spielstile: wie viel Bewertung (Centipawns) darf ein Zug opfern, um aggressiver zu sein?
  const STYLES = {
    solid: { label: "Solid", icon: "♖", multipv: 3, tol: 20, prefer: "quiet" },
    balanced: { label: "Balanced", icon: "♗", multipv: 1, tol: 0, prefer: "best" },
    aggressive: { label: "Aggressive", icon: "♘", multipv: 4, tol: 60, prefer: "attack" },
    allin: { label: "All-in", icon: "♛", multipv: 5, tol: 150, prefer: "attack" },
  };
  const settings = { style: "balanced", think: 0.8 };
  try {
    const saved = JSON.parse(localStorage.getItem("chessTrainerSettings") || "null");
    if (saved && STYLES[saved.style]) settings.style = saved.style;
    if (saved && saved.think >= 0.3 && saved.think <= 3) settings.think = saved.think;
  } catch (e) {}
  function saveSettings() {
    try { localStorage.setItem("chessTrainerSettings", JSON.stringify(settings)); } catch (e) {}
  }

  const ALL_RIGHTS = { K: true, Q: true, k: true, q: true };
  const state = {
    enabled: true,
    placement: null,
    prevGrid: null,
    grid: null,
    turn: "w",
    ep: "-",
    castling: { ...ALL_RIGHTS },
    requestedFen: null,
    result: null, // letzte Engine-Antwort für die aktuelle Stellung
    warnedNoBoard: false,
  };

  // ---------- Brett lesen ----------
  const findBoard = () => document.querySelector("wc-chess-board") || document.querySelector("chess-board");

  function squareOf(el) {
    for (const cls of el.classList) {
      const m = /^square-(\d)(\d)$/.exec(cls);
      if (m) return { file: +m[1], rank: +m[2] };
    }
    return null;
  }

  function readPieces(board) {
    const out = [];
    for (const el of board.querySelectorAll(".piece")) {
      let c = null, t = null;
      for (const cls of el.classList) {
        const m = /^([wb])([pnbrqk])$/.exec(cls);
        if (m) { c = m[1]; t = m[2]; }
      }
      const sq = squareOf(el);
      if (c && sq) out.push({ c, t, file: sq.file, rank: sq.rank });
    }
    return out;
  }

  function readHighlights(board) {
    const out = [];
    for (const el of board.querySelectorAll(".highlight")) {
      const sq = squareOf(el);
      if (sq) out.push(sq);
    }
    return out;
  }

  // ---------- Pfeil ----------
  const SVG_NS = "http://www.w3.org/2000/svg";

  function ensureOverlay(board) {
    let svg = board.querySelector(":scope > svg.schach-trainer");
    if (!svg) {
      svg = document.createElementNS(SVG_NS, "svg");
      svg.setAttribute("class", "schach-trainer");
      svg.setAttribute("viewBox", "0 0 800 800");
      svg.style.cssText = "position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none;z-index:50;";
      board.appendChild(svg);
    }
    return svg;
  }

  function center(file, rank, flipped) {
    const x = flipped ? 8 - file + 0.5 : file - 0.5;
    const y = flipped ? rank - 0.5 : 8 - rank + 0.5;
    return { x: x * 100, y: y * 100 };
  }

  function svgEl(svg, name, attrs) {
    const e = document.createElementNS(SVG_NS, name);
    for (const k in attrs) e.setAttribute(k, attrs[k]);
    svg.appendChild(e);
    return e;
  }

  function drawArrow(board, flipped, uci) {
    const svg = ensureOverlay(board);
    svg.replaceChildren();
    if (!uci) return;
    const a = center(uci.charCodeAt(0) - 96, +uci[1], flipped);
    const b = center(uci.charCodeAt(2) - 96, +uci[3], flipped);
    const color = "rgba(46, 204, 113, 0.85)";
    svgEl(svg, "circle", { cx: a.x, cy: a.y, r: 46, fill: "none", stroke: color, "stroke-width": 8 });
    svgEl(svg, "circle", { cx: b.x, cy: b.y, r: 46, fill: "none", stroke: color, "stroke-width": 8 });
    const dx = b.x - a.x, dy = b.y - a.y, len = Math.hypot(dx, dy) || 1;
    const ux = dx / len, uy = dy / len, head = 34;
    const ex = b.x - ux * 40, ey = b.y - uy * 40;
    svgEl(svg, "line", {
      x1: a.x + ux * 40, y1: a.y + uy * 40, x2: ex - ux * head * 0.6, y2: ey - uy * head * 0.6,
      stroke: color, "stroke-width": 16, "stroke-linecap": "round",
    });
    const px = -uy, py = ux;
    svgEl(svg, "polygon", {
      points: [
        [ex, ey],
        [ex - ux * head + px * head * 0.7, ey - uy * head + py * head * 0.7],
        [ex - ux * head - px * head * 0.7, ey - uy * head - py * head * 0.7],
      ].map((p) => p.join(",")).join(" "),
      fill: color,
    });
  }

  function clearOverlay() {
    document.querySelectorAll("svg.schach-trainer").forEach((s) => s.replaceChildren());
  }

  // ---------- Panel (chess style) ----------
  const CSS = `
  #st-panel{position:fixed;z-index:2147483646;box-sizing:border-box;min-width:300px;
    background:linear-gradient(180deg,#3a2817 0%,#2a1c10 100%);color:#f3e6c8;
    border:2px solid #c9a45c;border-radius:10px;box-shadow:0 8px 24px rgba(0,0,0,.45), inset 0 0 0 1px rgba(255,230,170,.08);
    font:14px/1.35 Georgia,"Times New Roman",serif;user-select:none}
  #st-panel *{box-sizing:border-box}
  #st-panel .st-head{display:flex;align-items:center;gap:8px;padding:6px 10px;cursor:move;
    border-bottom:1px solid rgba(201,164,92,.45);
    background:repeating-linear-gradient(90deg,rgba(201,164,92,.10) 0 14px,transparent 14px 28px)}
  #st-panel .st-logo{width:26px;height:26px;display:block;filter:drop-shadow(0 1px 1px rgba(0,0,0,.5))}
  #st-panel .st-title{font-weight:700;letter-spacing:.06em;font-variant:small-caps;font-size:15px;color:#e8c977}
  #st-panel .st-turn{margin-left:auto;font-size:12px;padding:2px 9px;border-radius:999px;border:1px solid #c9a45c;white-space:nowrap}
  #st-panel .st-turn.me{background:#e8c977;color:#2a1c10;font-weight:700}
  #st-panel .st-btn{background:none;border:1px solid rgba(201,164,92,.6);color:#e8c977;border-radius:5px;
    width:24px;height:22px;cursor:pointer;font:14px Georgia,serif;line-height:1;padding:0}
  #st-panel .st-btn:hover{background:rgba(201,164,92,.18)}
  #st-panel .st-body{padding:9px 10px 10px;display:grid;gap:9px}
  #st-panel.collapsed .st-body{display:none}
  #st-panel .st-bar{position:relative;height:16px;border-radius:4px;overflow:hidden;background:#1b120a;border:1px solid #c9a45c}
  #st-panel .st-bar i{position:absolute;left:0;top:0;bottom:0;background:#f4ead2;transition:width .35s ease}
  #st-panel .st-bar b{position:absolute;left:50%;top:-2px;bottom:-2px;width:1px;background:#c9a45c}
  #st-panel .st-bar span{position:absolute;right:6px;top:0;font:700 11px/16px Georgia,serif;color:#c9a45c}
  #st-panel .st-tiles{display:grid;grid-template-columns:1.15fr 1fr 1fr;gap:6px}
  #st-panel .st-tile{background:rgba(0,0,0,.25);border:1px solid rgba(201,164,92,.35);border-radius:6px;padding:5px 8px;min-width:0}
  #st-panel .st-lbl{font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:#bfa77a}
  #st-panel .st-val{font-size:18px;font-weight:700;color:#fff6e0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  #st-panel .st-val.ev{transition:color .3s}
  #st-panel .st-val .pc{font-size:22px;vertical-align:-2px;margin-right:3px}
  #st-panel .st-mate{display:none;text-align:center;font-weight:700;font-variant:small-caps;letter-spacing:.05em;
    padding:5px 8px;border-radius:6px;font-size:15px}
  #st-panel .st-mate.win{display:block;background:#2e7d4f;color:#fff;border:1px solid #6fd39a}
  #st-panel .st-mate.loss{display:block;background:#7d2e2e;color:#fff;border:1px solid #e08a8a}
  #st-panel.off .st-body{opacity:.4}
  #st-panel .st-btn.on{background:#e8c977;color:#2a1c10}
  #st-panel .st-settings{padding:9px 10px 11px;border-bottom:1px solid rgba(201,164,92,.45);background:rgba(0,0,0,.28);display:grid;gap:7px}
  #st-panel .st-settings[hidden]{display:none}
  #st-panel .st-seg{display:grid;grid-template-columns:repeat(4,1fr);gap:4px}
  #st-panel .st-seg button{background:rgba(0,0,0,.3);border:1px solid rgba(201,164,92,.45);color:#f3e6c8;border-radius:6px;
    padding:5px 2px;cursor:pointer;font:600 12px Georgia,serif;white-space:nowrap}
  #st-panel .st-seg button span{display:block;font-size:19px;line-height:1.1}
  #st-panel .st-seg button:hover{background:rgba(201,164,92,.18)}
  #st-panel .st-seg button.sel{background:#e8c977;color:#2a1c10;border-color:#e8c977}
  #st-panel .st-row{display:flex;align-items:center;gap:10px}
  #st-panel .st-row b{font-weight:700;color:#fff6e0;min-width:42px;text-align:right}
  #st-panel input[type=range]{flex:1;accent-color:#c9a45c}
  `;

  let panel = null;
  let ui = {};
  let dragged = null; // {x,y} wenn der Nutzer das Panel verschoben hat

  try {
    const saved = JSON.parse(localStorage.getItem("schachTrainerPanel") || "null");
    if (saved && typeof saved.x === "number") dragged = saved;
  } catch (e) {}

  function buildPanel() {
    const style = document.createElement("style");
    style.textContent = CSS;
    document.documentElement.appendChild(style);

    panel = document.createElement("div");
    panel.id = "st-panel";
    panel.innerHTML = `
      <div class="st-head">
        <img class="st-logo" alt="" src="${chrome.runtime.getURL("icons/logo96.png")}"><span class="st-title">Chess Trainer</span>
        <span class="st-turn">…</span>
        <button class="st-btn" data-act="gear" title="Settings">⚙</button>
        <button class="st-btn" data-act="power" title="On/off (Alt+X)">⏻</button>
        <button class="st-btn" data-act="fold" title="Collapse">–</button>
      </div>
      <div class="st-settings" hidden>
        <div class="st-lbl">Play style</div>
        <div class="st-seg">
          ${Object.entries(STYLES).map(([k, v]) => `<button data-style="${k}"><span>${v.icon}</span>${v.label}</button>`).join("")}
        </div>
        <div class="st-lbl">Think time</div>
        <div class="st-row"><input type="range" min="0.3" max="3" step="0.1" data-k="think"><b data-k="thinkOut"></b></div>
      </div>
      <div class="st-body">
        <div class="st-bar" title="Evaluation bar (light = White)"><i></i><b></b><span></span></div>
        <div class="st-mate"></div>
        <div class="st-tiles">
          <div class="st-tile"><div class="st-lbl" data-k="moveLbl">Best move</div><div class="st-val" data-k="move">–</div></div>
          <div class="st-tile"><div class="st-lbl">Evaluation</div><div class="st-val ev" data-k="eval">–</div></div>
          <div class="st-tile"><div class="st-lbl">Material</div><div class="st-val" data-k="mat">–</div></div>
        </div>
      </div>`;
    document.documentElement.appendChild(panel);

    ui = {
      turn: panel.querySelector(".st-turn"),
      barFill: panel.querySelector(".st-bar i"),
      barText: panel.querySelector(".st-bar span"),
      mate: panel.querySelector(".st-mate"),
    };
    panel.querySelectorAll("[data-k]").forEach((el) => (ui[el.dataset.k] = el));

    panel.querySelector('[data-act="power"]').addEventListener("click", toggleEnabled);
    const gear = panel.querySelector('[data-act="gear"]');
    const box = panel.querySelector(".st-settings");
    gear.addEventListener("click", () => {
      box.hidden = !box.hidden;
      gear.classList.toggle("on", !box.hidden);
    });
    const syncSettingsUi = () => {
      box.querySelectorAll("[data-style]").forEach((b) => b.classList.toggle("sel", b.dataset.style === settings.style));
      ui.think.value = settings.think;
      ui.thinkOut.textContent = settings.think.toFixed(1) + " s";
    };
    box.querySelectorAll("[data-style]").forEach((b) =>
      b.addEventListener("click", () => {
        settings.style = b.dataset.style;
        saveSettings();
        syncSettingsUi();
        reanalyze();
      })
    );
    ui.think.addEventListener("input", () => {
      settings.think = +(+ui.think.value).toFixed(1);
      ui.thinkOut.textContent = settings.think.toFixed(1) + " s";
    });
    ui.think.addEventListener("change", () => { saveSettings(); reanalyze(); });
    syncSettingsUi();
    panel.querySelector('[data-act="fold"]').addEventListener("click", (e) => {
      panel.classList.toggle("collapsed");
      e.currentTarget.textContent = panel.classList.contains("collapsed") ? "+" : "–";
    });

    // Ziehen am Kopf
    const head = panel.querySelector(".st-head");
    head.addEventListener("mousedown", (e) => {
      if (e.target.closest("button")) return;
      const r = panel.getBoundingClientRect();
      const offX = e.clientX - r.left, offY = e.clientY - r.top;
      const move = (ev) => {
        dragged = { x: Math.max(0, ev.clientX - offX), y: Math.max(0, ev.clientY - offY) };
        panel.style.left = dragged.x + "px";
        panel.style.top = dragged.y + "px";
      };
      const up = () => {
        document.removeEventListener("mousemove", move);
        document.removeEventListener("mouseup", up);
        try { localStorage.setItem("schachTrainerPanel", JSON.stringify(dragged)); } catch (err) {}
      };
      document.addEventListener("mousemove", move);
      document.addEventListener("mouseup", up);
    });
    head.addEventListener("dblclick", () => {
      dragged = null; // Doppelklick = zurück an die Standardposition über dem Brett
      try { localStorage.removeItem("schachTrainerPanel"); } catch (err) {}
    });
  }

  function placePanel(board) {
    if (!panel) buildPanel();
    panel.style.display = "block";
    const r = board.getBoundingClientRect();
    panel.style.width = Math.max(300, Math.min(r.width, 560)) + "px";
    if (dragged) {
      panel.style.left = dragged.x + "px";
      panel.style.top = dragged.y + "px";
      return;
    }
    const h = panel.offsetHeight;
    let top = r.top - h - 8;
    if (top < 6) top = 6; // kein Platz über dem Brett -> oben im Fenster, notfalls verschiebbar
    panel.style.left = Math.max(6, r.left) + "px";
    panel.style.top = top + "px";
  }

  function hidePanel() {
    if (panel) panel.style.display = "none";
  }

  // ---------- Werte aufbereiten ----------
  // Engine meldet aus Sicht der Seite am Zug -> in Sicht von "me" umrechnen
  function fromMyView(score, turn, me) {
    if (!score) return null;
    const sign = turn === me ? 1 : -1;
    if (score.mate !== undefined) return { mate: score.mate * sign };
    return { cp: score.cp * sign };
  }

  // Bewertung nur als Wort, von dunkelrot (schlecht) bis hellgrün (super)
  const SCALE = [
    { max: -300, word: "Terrible", color: "#a3201a" },
    { max: -120, word: "Bad", color: "#d1452b" },
    { max: -40, word: "Dubious", color: "#e58a2e" },
    { max: 40, word: "Equal", color: "#dcc54d" },
    { max: 120, word: "Good", color: "#a8d24b" },
    { max: 300, word: "Great", color: "#86dc55" },
    { max: Infinity, word: "Excellent", color: "#9cf06e" },
  ];
  function evalWord(my) {
    if (my.mate !== undefined) return my.mate > 0 ? { word: "Super", color: "#c4ff9a" } : { word: "Lost", color: "#7a0f0f" };
    return SCALE.find((s) => my.cp < s.max) || SCALE[SCALE.length - 1];
  }

  // Balkenanteil für Weiß (0..1)
  function whiteShare(score, turn) {
    if (!score) return 0.5;
    const s = turn === "w" ? 1 : -1;
    if (score.mate !== undefined) return score.mate * s > 0 ? 1 : 0;
    return 1 / (1 + Math.exp(-(score.cp * s) / 250));
  }

  // Engine-Score (Sicht der Seite am Zug) -> vergleichbare Zahl
  const val = (sc) => (sc.mate !== undefined ? (sc.mate > 0 ? 100000 - sc.mate : -100000 - sc.mate) : sc.cp);

  // Wählt je nach Spielstil eine der Kandidatenlinien
  function chooseLine(grid, res, isMyTurn) {
    const lines = res.lines && res.lines.length ? res.lines : [{ move: res.bestmove, score: res.score, pv: res.pv }];
    const st = STYLES[settings.style];
    const best = lines[0];
    if (!isMyTurn || st.prefer === "best" || lines.length < 2) return best;
    if (best.score.mate !== undefined && best.score.mate > 0) return best; // Matt immer nehmen
    const bestVal = val(best.score);
    const ok = lines.filter((l) => l.score && bestVal - val(l.score) <= st.tol && val(l.score) > -90000);
    if (!ok.length) return best;
    const G = ChessFen;
    let pick = best, pickScore = -Infinity;
    for (const l of ok) {
      const agg = G.aggression(grid, l.move);
      const sc = (st.prefer === "quiet" ? -agg : agg) * 100 - (bestVal - val(l.score)) * 0.5;
      if (sc > pickScore) { pickScore = sc; pick = l; }
    }
    return pick;
  }

  function setEval(text, color) {
    ui.eval.textContent = text;
    ui.eval.style.color = color || "";
  }

  function renderPanel(board, info) {
    placePanel(board);
    const G = ChessFen;
    const { grid, turn, me, res, thinking } = info;

    ui.turn.textContent = turn === me ? "Your move" : "Bot's move";
    ui.turn.classList.toggle("me", turn === me);
    panel.classList.toggle("off", !state.enabled);

    const matW = G.material(grid);
    const matMe = me === "w" ? matW : -matW;
    ui.mat.textContent = matMe === 0 ? "Even" : (matMe > 0 ? "+" : "−") + Math.abs(matMe);

    if (!state.enabled) {
      ui.move.textContent = "Off";
      setEval("–");
      ui.mate.className = "st-mate";
      return;
    }
    if (!res || thinking) {
      ui.move.textContent = "…";
      if (!res) setEval("…");
      return;
    }
    if (!res.bestmove) {
      ui.move.textContent = "–";
      setEval("Game over");
      ui.mate.className = "st-mate";
      return;
    }

    const line = chooseLine(grid, res, turn === me);
    info.line = line;
    ui.moveLbl.textContent = turn !== me ? "Bot expects" : settings.style === "balanced" ? "Best move" : STYLES[settings.style].label + " move";
    ui.move.innerHTML = `<span class="pc">${G.pieceIcon(grid, line.move)}</span>${G.toSan(grid, line.move)}`;

    const my = fromMyView(line.score, turn, me);
    if (my) {
      const w = evalWord(my);
      setEval(w.word, w.color);
      if (my.mate !== undefined) {
        const n = Math.abs(my.mate);
        const mv = n === 1 ? "move" : "moves";
        ui.mate.className = "st-mate " + (my.mate > 0 ? "win" : "loss");
        ui.mate.textContent = my.mate > 0 ? `♚ Checkmate in ${n} ${mv}` : `⚠ Bot mates you in ${n} ${mv}`;
      } else {
        ui.mate.className = "st-mate";
      }
    }
    ui.barFill.style.width = (whiteShare(line.score, turn) * 100).toFixed(1) + "%";
  }

  // ---------- Engine ----------
  function sendMsg(msg) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(msg, (res) => {
          if (chrome.runtime.lastError) resolve({ error: chrome.runtime.lastError.message });
          else resolve(res);
        });
      } catch (e) {
        resolve({ error: String(e) });
      }
    });
  }

  async function analyze(fen) {
    const msg = {
      type: "analyze",
      fen,
      movetime: Math.round(settings.think * 1000),
      multipv: STYLES[settings.style].multipv,
    };
    let res = await sendMsg(msg);
    if (res && res.error) {
      await sendMsg({ type: "ensure-offscreen" });
      await new Promise((r) => setTimeout(r, 400));
      res = await sendMsg(msg);
    }
    return res;
  }

  // ---------- Hauptschleife ----------
  const onComputerPage = () => !CFG.onlyVsComputer || location.pathname.startsWith("/play/computer");

  function resetGame() {
    state.castling = { ...ALL_RIGHTS };
    state.turn = "w";
    state.ep = "-";
    state.prevGrid = null;
    state.requestedFen = null;
    state.result = null;
  }

  function tick() {
    if (!onComputerPage()) {
      clearOverlay();
      hidePanel();
      return;
    }
    const board = findBoard();
    if (!board) {
      if (!state.warnedNoBoard) {
        console.log("[Chess Trainer] Board not found (wc-chess-board).");
        state.warnedNoBoard = true;
      }
      hidePanel();
      return;
    }
    state.warnedNoBoard = false;

    const pieces = readPieces(board);
    if (pieces.length < 2) return;

    const G = ChessFen;
    const grid = G.gridFromPieces(pieces);
    const placement = G.placement(grid);
    const flipped = board.classList.contains("flipped");
    const me = flipped ? "b" : "w";

    if (placement !== state.placement) {
      state.placement = placement;
      if (placement === G.START_PLACEMENT) {
        resetGame();
      } else {
        const mv = G.detectMove(state.prevGrid, grid);
        const mover = mv.mover || G.moverFromHighlights(grid, readHighlights(board));
        state.turn = mover ? G.other(mover) : "w";
        state.ep = mv.ep;
      }
      state.castling = G.updateCastling(state.castling, grid);
      state.prevGrid = grid;
      state.result = null;
    }
    state.grid = grid;

    const fen = G.buildFen(grid, state.turn, state.castling, state.ep);
    const res = state.result && state.result.fen === fen ? state.result : null;

    if (!state.enabled) {
      clearOverlay();
      renderPanel(board, { grid, turn: state.turn, me, res: null, thinking: false });
      return;
    }

    const info = { grid, turn: state.turn, me, res, thinking: !res };
    renderPanel(board, info);

    // Pfeil nur, wenn du am Zug bist
    if (res && res.bestmove && state.turn === me && info.line) drawArrow(board, flipped, info.line.move);
    else clearOverlay();

    if (res || state.requestedFen === fen) return;
    state.requestedFen = fen;

    analyze(fen).then((r) => {
      if (state.requestedFen !== fen) return; // Stellung hat sich inzwischen geändert
      if (!r || r.superseded) return;
      if (!r.ok) {
        console.warn("[Chess Trainer] Engine error:", r.error);
        setTimeout(() => { if (state.requestedFen === fen) state.requestedFen = null; }, 2000);
        return;
      }
      state.result = r;
    });
  }

  function reanalyze() {
    state.requestedFen = null;
    state.result = null;
  }

  function toggleEnabled() {
    state.enabled = !state.enabled;
    state.requestedFen = null;
    state.result = null;
    if (!state.enabled) clearOverlay();
  }

  document.addEventListener("keydown", (e) => {
    if (e.altKey && e.key.toLowerCase() === "x") toggleEnabled();
  });

  setInterval(tick, CFG.pollMs);
  console.log("[Chess Trainer] loaded. Alt+X = on/off.");
})();
